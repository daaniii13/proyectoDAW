<template>
    <section class="seccion-testimonios">
        <div class="container py-5">
            <div class="seccion-testimonios__cabecera mb-4">
                <span class="seccion-testimonios__etiqueta">Opiniones reales</span>
                <h2 class="mb-3">Lo que opinan nuestros usuarios</h2>
                <p class="texto-suave mb-0">
                    Estudiantes y profesores comparten su experiencia con la plataforma y el impacto de los cursos en su aprendizaje.
                </p>
            </div>

            <div class="testimonios-grid">
                <article
                    v-for="testimonio in testimonios"
                    :key="testimonio.id"
                    class="tarjeta-testimonio"
                >
                    <div class="tarjeta-testimonio__superior">
                        <div class="tarjeta-testimonio__avatar">
                            {{ obtenerIniciales(testimonio.nombre) }}
                        </div>

                        <div>
                            <p class="tarjeta-testimonio__nombre mb-1">
                                {{ testimonio.nombre }}
                            </p>
                            <p class="tarjeta-testimonio__rol mb-0">
                                {{ testimonio.rol }}
                            </p>
                        </div>
                    </div>

                    <p class="tarjeta-testimonio__texto">
                        “{{ testimonio.mensaje }}”
                    </p>

                    <div class="tarjeta-testimonio__valoracion">
                        <span
                            v-for="estrella in 5"
                            :key="estrella"
                            class="tarjeta-testimonio__estrella"
                        >
                            ★
                        </span>
                    </div>
                </article>
            </div>
        </div>
    </section>
</template>

<script setup>
// Nota: Este componente utiliza `<script setup>`, que es la sintaxis de Composition API más moderna de Vue.
// Todo lo que se defina aquí (variables, funciones) está automáticamente disponible en el <template>.

// Define un array estático con los datos de los testimonios.
// En una aplicación real, esto podría venir de una API.
const testimonios = [
    {
        id: 1,
        nombre: 'María Gómez',
        rol: 'Estudiante de desarrollo web',
        mensaje: 'La plataforma me permitió encontrar cursos muy bien explicados y seguir mi progreso de forma clara.'
    },
    {
        id: 2,
        nombre: 'Daniel Ruiz',
        rol: 'Profesor de backend',
        mensaje: 'Subir materiales y organizar contenidos resulta muy cómodo. La interfaz transmite orden y confianza.'
    },
    {
        id: 3,
        nombre: 'Lucía Fernández',
        rol: 'Estudiante de UX/UI',
        mensaje: 'Me gustó especialmente el buscador y la claridad con la que se presenta la información de cada curso.'
    },
    {
        id: 4,
        nombre: 'Javier Morales',
        rol: 'Profesor de frontend',
        mensaje: 'La estructura del panel facilita la gestión de alumnos y recursos. Tiene mucho potencial para equipos docentes.'
    }
]

// Función auxiliar para extraer las iniciales de un nombre completo.
// Ejemplo: "María Gómez" -> "MG"
function obtenerIniciales(nombre) {
    return nombre
        .split(' ')                  // Divide el string en un array de palabras usando el espacio como separador.
        .map((parte) => parte.charAt(0)) // Crea un nuevo array extrayendo solo el primer carácter (índice 0) de cada palabra.
        .join('')                    // Une el array de caracteres en un solo string (sin separadores).
        .slice(0, 2)                 // Toma solo los primeros 2 caracteres por si hay nombres muy largos (ej. 3 o más palabras).
        .toUpperCase()               // Convierte el resultado a mayúsculas para que quede como iniciales (ej. "mg" -> "MG").
}
</script>
