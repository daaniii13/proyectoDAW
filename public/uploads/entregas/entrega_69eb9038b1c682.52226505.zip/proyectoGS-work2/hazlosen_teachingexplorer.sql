-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-04-2026 a las 14:32:21
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hazlosen_teachingexplorer`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario`
--

CREATE TABLE `comentario` (
  `id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `contenido` longtext NOT NULL,
  `destacado` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comentario`
--

INSERT INTO `comentario` (`id`, `curso_id`, `usuario_id`, `contenido`, `destacado`, `fecha_creacion`) VALUES
(3, 10, 3, 'hola', 0, '2026-04-10 15:27:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` longtext NOT NULL,
  `nivel` varchar(50) NOT NULL,
  `modalidad` varchar(50) NOT NULL,
  `duracion` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `profesor_id` int(11) NOT NULL,
  `banner_url` varchar(255) DEFAULT NULL,
  `mapa_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `curso`
--

INSERT INTO `curso` (`id`, `titulo`, `descripcion`, `nivel`, `modalidad`, `duracion`, `precio`, `estado`, `fecha_creacion`, `profesor_id`, `banner_url`, `mapa_url`) VALUES
(10, 'JavaScript', 'Aprende JavaScript', 'Intermedio', 'Online', '8 dias', 5.00, 'activo', '2026-03-31 14:49:11', 29, 'https://images.unsplash.com/photo-1518770660439-4636190af475', NULL),
(11, 'Inicio a JavaScript', 'En este curso aprenderá acerca de como programar con JavaScript sin experiencia previa.', 'Inicial', 'Online', '2 semanas', 6.00, 'activo', '2026-04-15 07:21:46', 43, 'https://imgs.search.brave.com/NRgLn4_WDmk5zz5oFgRWcKK01VJz-N1XSHWEGjK4OsU/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9jZG4u/dmVjdG9yc3RvY2su/Y29tL2kvNTAwcC8y/Ni8zMy9qYXZhc2Ny/aXB0LXByb2dyYW1t/aW5nLWJhbm5lci12/ZWN0b3ItMjQxOTI2/MzMuanBn', NULL),
(12, 'tt', 'tt', 'Intermedio', 'Online', '2 semanas', 6.00, 'activo', '2026-04-16 10:32:40', 43, 'https://es.vecteezy.com/vectores-gratis/banner-moderno', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20260330123000', '2026-03-30 13:55:09', 9),
('DoctrineMigrations\\Version20260416090000', '2026-04-16 09:58:49', 19);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrega_tarea`
--

CREATE TABLE `entrega_tarea` (
  `id` int(11) NOT NULL,
  `tarea_id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `archivo_entrega` varchar(255) NOT NULL,
  `comentario` longtext DEFAULT NULL,
  `fecha_entrega` datetime NOT NULL DEFAULT current_timestamp(),
  `estado_revision` varchar(30) NOT NULL DEFAULT 'pendiente',
  `nota` int(11) DEFAULT NULL,
  `comentario_profesor` longtext DEFAULT NULL,
  `fecha_revision` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `entrega_tarea`
--

INSERT INTO `entrega_tarea` (`id`, `tarea_id`, `estudiante_id`, `archivo_entrega`, `comentario`, `fecha_entrega`, `estado_revision`, `nota`, `comentario_profesor`, `fecha_revision`) VALUES
(1, 2, 28, 'entrega_69df41a6bf8873.34952793.', NULL, '2026-04-15 07:43:34', 'pendiente', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscripcion`
--

CREATE TABLE `inscripcion` (
  `id` int(11) NOT NULL,
  `progreso` int(11) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `fecha_inscripcion` datetime NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `referencia_pago` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `inscripcion`
--

INSERT INTO `inscripcion` (`id`, `progreso`, `estado`, `fecha_inscripcion`, `estudiante_id`, `curso_id`, `referencia_pago`) VALUES
(8, 0, 'pendiente_validacion', '2026-04-10 15:36:02', 37, 10, 'PAGO-CURSO-10-USER-37'),
(9, 100, 'completada', '2026-04-15 07:41:44', 28, 11, 'PAGO-CURSO-11-USER-28'),
(11, 0, 'activa', '2026-04-16 06:34:04', 39, 11, 'PAGO-CURSO-11-USER-39'),
(12, 0, 'rechazada', '2026-04-16 06:38:59', 30, 11, 'PAGO-CURSO-11-USER-30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `messenger_messages`
--

CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recuperacion_contrasena`
--

CREATE TABLE `recuperacion_contrasena` (
  `id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `fecha_expiracion` datetime NOT NULL,
  `usado` tinyint(4) NOT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recurso_curso`
--

CREATE TABLE `recurso_curso` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `contenido` longtext NOT NULL,
  `orden` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `archivo_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `recurso_curso`
--

INSERT INTO `recurso_curso` (`id`, `titulo`, `tipo`, `contenido`, `orden`, `curso_id`, `archivo_url`) VALUES
(4, 'Lección 1', 'documento', 'Conceptos básicos', 1, 11, 'recurso_69df3ce763d8b0.46590575.pdf'),
(5, 'Lección 2', 'video', 'https://www.youtube.com/watch?v=g6n0jwOUbMo', 2, 11, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recurso_visto`
--

CREATE TABLE `recurso_visto` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `recurso_id` int(11) NOT NULL,
  `fecha_visto` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `recurso_visto`
--

INSERT INTO `recurso_visto` (`id`, `usuario_id`, `recurso_id`, `fecha_visto`) VALUES
(4, 28, 4, '2026-04-15 07:43:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `suscripcion_profesor`
--

CREATE TABLE `suscripcion_profesor` (
  `id` int(11) NOT NULL,
  `profesor_id` int(11) NOT NULL,
  `plan` varchar(50) NOT NULL DEFAULT 'basico',
  `estado` varchar(50) NOT NULL DEFAULT 'pendiente',
  `limite_cursos` int(11) NOT NULL DEFAULT 1,
  `fecha_solicitud` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_aprobacion` datetime DEFAULT NULL,
  `plan_solicitado` varchar(50) DEFAULT NULL,
  `tipo_solicitud` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `suscripcion_profesor`
--

INSERT INTO `suscripcion_profesor` (`id`, `profesor_id`, `plan`, `estado`, `limite_cursos`, `fecha_solicitud`, `fecha_aprobacion`, `plan_solicitado`, `tipo_solicitud`) VALUES
(15, 28, 'pro', 'cancelada', 0, '2026-03-30 20:45:00', '2026-03-30 20:47:46', NULL, NULL),
(16, 29, 'basico', 'activa', 1, '2026-03-30 20:48:52', '2026-03-30 20:49:52', NULL, NULL),
(17, 30, 'pro', 'activa', 5, '2026-03-30 20:49:25', '2026-03-30 20:49:49', NULL, NULL),
(19, 34, 'premium', 'activa', 999, '2026-04-08 09:33:02', '2026-04-08 10:00:30', NULL, NULL),
(21, 39, 'premium', 'activa', 999, '2026-04-15 06:28:45', '2026-04-15 06:29:08', NULL, NULL),
(22, 42, 'premium', 'activa', 999, '2026-04-15 06:44:17', '2026-04-15 06:46:56', NULL, NULL),
(23, 43, 'pro', 'activa', 5, '2026-04-15 06:45:05', '2026-04-15 06:46:53', NULL, NULL),
(24, 44, 'basico', 'activa', 1, '2026-04-15 06:45:43', '2026-04-15 06:46:51', NULL, NULL),
(25, 45, 'basico', 'activa', 1, '2026-04-15 06:46:31', '2026-04-15 06:46:49', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarea_curso`
--

CREATE TABLE `tarea_curso` (
  `id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` longtext NOT NULL,
  `fecha_limite` datetime DEFAULT NULL,
  `archivo_profesor` varchar(255) DEFAULT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tarea_curso`
--

INSERT INTO `tarea_curso` (`id`, `curso_id`, `titulo`, `descripcion`, `fecha_limite`, `archivo_profesor`, `fecha_creacion`) VALUES
(2, 11, 'Cuestionario básico', '¿Qué es JavaScript y para qué se utiliza?\r\n¿Cómo se declara una variable en JavaScript?\r\n¿Cuál es la diferencia entre var, let y const?\r\n¿Qué tipos de datos existen en JavaScript?\r\n¿Qué es un operador en JavaScript? Menciona algunos ejemplos.\r\n¿Cómo se escribe un comentario en JavaScript?\r\n¿Qué es una función y cómo se define?\r\n¿Qué es un parámetro en una función?\r\n¿Qué es un valor de retorno en una función?\r\n¿Cómo se crea un condicional if?\r\n¿Qué hace la estructura else?\r\n¿Qué es un bucle for y para qué sirve?\r\n¿Qué es un bucle while?\r\n¿Qué es un array (arreglo)?\r\n¿Cómo se accede a un elemento de un array?', '2026-04-17 00:00:00', NULL, '2026-04-15 07:27:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(180) NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`roles`)),
  `password` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `activo` tinyint(4) NOT NULL,
  `foto_perfil` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `nombre`, `fecha_registro`, `activo`, `foto_perfil`) VALUES
(3, 'admin@gmail.com', '[\"ROLE_ADMIN\"]', '$2y$13$wbxPAYhjP9w6kO/YPxT5sePeTUtscog94qRXpUttY8udv/KM3d3x2', 'Admin', '2026-03-24 17:01:15', 1, 'perfil_69e091aed835f2.45057127.jpg'),
(25, 'marialopez@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$iGPNm2X.yhsAUHKzVrWpJ.6RNbQoi.hmNpWfZ3NiFpCLTKGqyvn52', 'Maria Lopez', '2026-03-30 20:33:06', 1, 'perfil_69cb0e5f6a7945.51905645.webp'),
(26, 'saracampos@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$FzT4g8IYqlUJQDgaORrHL.o2VyDcg.QjdJFuuRoHx4MVqid.J.LKS', 'Sara Campos', '2026-03-30 20:34:00', 1, NULL),
(27, 'victorruiz@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$hPtcWy647XMv1458NfJqhOsxnoesnUcgEU8xp9xJREbIV0MWhxD7.', 'Victor Ruiz', '2026-03-30 20:35:13', 1, NULL),
(28, 'cristinapon@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$WEdWgDkHcGvE0LkLqO0QQ.zbT2HhlOzd5Uofx2ktBeLkw2lr6asHi', 'Cristina Ponce', '2026-03-30 20:36:30', 1, 'perfil_69df46421d93e0.09841722.webp'),
(29, 'eusebiolo@gmail.com', '[\"ROLE_PROFESOR\"]', '$2y$13$vgDaJBf6Aapxo6sG1u29r.6WmUth3VVoZOhgDuajwh5dOPU7x3TTW', 'Eusebio Lopez', '2026-03-30 20:48:51', 1, NULL),
(30, 'pepelo@gmail.com', '[\"ROLE_PROFESOR\"]', '$2y$13$56dlPaZKL9VL/m9/so1KLuZdB4w.JqF3e40QPtssTnZnvKDx2OvsC', 'Pepe Lobregón', '2026-03-30 20:49:24', 1, NULL),
(34, 'yihate7551@nyspring.com', '[\"ROLE_ESTUDIANTE\",\"ROLE_PROFESOR\"]', '$2y$13$Tnd0sTYr39GSKLoTqCaJ8.gCMKHdaI8dKnS1VGz8duq5.9IzkiPlW', 'Juan Thomson', '2026-04-08 09:33:02', 1, NULL),
(37, 'castellanogomezcarlos@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$dXpArCjTqCqiVO/.Qfftkui8MkYc/96ppDtIimSpO8ILlZRMFDtli', 'Carlos Castellano', '2026-04-10 15:34:47', 1, NULL),
(39, 'rodrigoju@gmail.com', '[\"ROLE_ESTUDIANTE\",\"ROLE_PROFESOR\"]', '$2y$13$vbbvC1qI5/oIzGhwRr7BdeDtUA.h4wKhhIqVhXJK/EJInvSAXuM8i', 'Rodrigo Juárez', '2026-04-15 06:28:44', 1, 'perfil_69e0824d2a6181.09492300.webp'),
(40, 'admin2@gmail.com', '[\"ROLE_ADMIN\"]', '$2y$13$O5YB.KcqwvRfdW/Xdyen7Od1xp2bmgyuIxDP14YPnU4MNtjrX1vsK', 'Admin2', '2026-04-15 06:32:24', 1, 'perfil_69e09202d72333.00190550.webp'),
(41, 'admin3@gmail.com', '[\"ROLE_ADMIN\"]', '$2y$13$bAn.c6ZBUPlBuTtxST17Qessz6PjUhnSp2/qORYP6gHGvq5wY5.TC', 'Admin3', '2026-04-15 06:32:53', 1, 'perfil_69e09229227920.80890804.webp'),
(42, 'danialcaraz@gmail.com', '[\"ROLE_ESTUDIANTE\",\"ROLE_PROFESOR\"]', '$2y$13$fMFqPDowoJoQOMF/3rp9pOkpzCDfMR8Py7nq5SuTcGiu3RPYE52ma', 'Daniel Alcaraz', '2026-04-15 06:44:17', 1, NULL),
(43, 'nataliaros@gmail.com', '[\"ROLE_ESTUDIANTE\",\"ROLE_PROFESOR\"]', '$2y$13$B0uIOuSS1k6x4HsDjMoOKebVQkxSUfexck9MEFjcqVMCMF6xOloX2', 'Natalia Ros', '2026-04-15 06:45:04', 1, NULL),
(44, 'isafernandez@gmail.com', '[\"ROLE_ESTUDIANTE\",\"ROLE_PROFESOR\"]', '$2y$13$JF9SPyYGJOtI6eKWAYnUCO.zXaKdozi9qHjADuaJoz5G3Ix9ZEUMq', 'Isa Fernández', '2026-04-15 06:45:43', 1, NULL),
(45, 'kiliamgrant@gmail.com', '[\"ROLE_ESTUDIANTE\",\"ROLE_PROFESOR\"]', '$2y$13$ayeL.5feJzaYJ3g.kZNJXek9mp92qs5L.H7Iwwh8xLzXvT1CnriQm', 'Kiliam Grant', '2026-04-15 06:46:30', 1, NULL),
(46, 'danisiu1379@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$mYF1N5zu2Vs/3JB8uZirkO0cmr.CLznauJqTxqUg.hWWHC83X1DC.', 'Daniel Muñoz', '2026-04-15 06:57:58', 1, NULL),
(47, 'anamar@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$7DdMxqJc4lrs67J1oSrFRuqi5xKN9XUhs5Oz5fahlKs9/GJNh/OWe', 'Ana María', '2026-04-15 07:08:17', 1, NULL),
(48, 'yoelcampos@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$WaTUtvI3o1EafirXhUx.Sux2GcqR2961mIya2aRXuahqz5XR3KT6K', 'Yoel Campos', '2026-04-15 07:08:50', 1, NULL),
(49, 'pedrocan@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$4PYZY1QoTGH8ssOCoU5Qyuy7D4I9KD3QvkfFOPNsYZ52tadauU0Dm', 'Pedro Cánovas', '2026-04-15 07:09:40', 1, NULL),
(50, 'albaramos@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$paPjnp/8h3CHbmN4zUuF3uChZ2KviWGAr4/014A0qlcJZcV8WrqTC', 'Alba Ramos', '2026-04-15 07:10:21', 1, NULL),
(51, 'sergioperez@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$uThdLWvxzcA95gCQgVjz0eUbCb3E7gw0ICOEd0izPNyZeGwZzqOOi', 'Sergio Pérez', '2026-04-15 07:12:06', 1, NULL),
(52, 'lucasgomez@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$LtCgR0S2lxM5423e2SfVIeAVIqNm0RJdkGIKmKJ4nYq27z25ItjEK', 'Lucas Gómez', '2026-04-15 07:12:28', 1, NULL),
(53, 'miriamdiaz@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$G5j44p8aBa6ELDZD7PCSfud98lPT0pmR0Bo67bh9fimlsYzu142Cq', 'Miriam Díaz', '2026-04-15 07:13:02', 1, NULL),
(54, 'lolacarmona@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$IQIz00kcyQwccC9n7cUik.9ym5YLfR1.bd5SC44Q5vZj8XL4LaDxO', 'Lola Carmona', '2026-04-15 07:13:40', 1, NULL),
(56, 'danonetecno13@gmail.com', '[\"ROLE_ESTUDIANTE\"]', '$2y$13$xwOqnmLm8XJDCcNw0sRxTe13nsTCNj9ryIo1l2LI33DaflduC.9eK', 'Danone', '2026-04-16 13:54:50', 1, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_COMENTARIO_CURSO` (`curso_id`),
  ADD KEY `FK_COMENTARIO_USUARIO` (`usuario_id`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CA3B40ECE52BD977` (`profesor_id`);

--
-- Indices de la tabla `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `entrega_tarea`
--
ALTER TABLE `entrega_tarea`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_ENTREGA_TAREA_ESTUDIANTE` (`tarea_id`,`estudiante_id`),
  ADD KEY `IDX_ENTREGA_TAREA_TAREA` (`tarea_id`),
  ADD KEY `IDX_ENTREGA_TAREA_ESTUDIANTE` (`estudiante_id`);

--
-- Indices de la tabla `inscripcion`
--
ALTER TABLE `inscripcion`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `estudiante_id` (`estudiante_id`,`curso_id`),
  ADD KEY `IDX_935E99F059590C39` (`estudiante_id`),
  ADD KEY `IDX_935E99F087CB4A1F` (`curso_id`);

--
-- Indices de la tabla `messenger_messages`
--
ALTER TABLE `messenger_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_75EA56E0FB7336F0E3BD61CE16BA31DBBF396750` (`queue_name`,`available_at`,`delivered_at`,`id`);

--
-- Indices de la tabla `recuperacion_contrasena`
--
ALTER TABLE `recuperacion_contrasena`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_32D59BF15F37A13B` (`token`),
  ADD KEY `IDX_32D59BF1DB38439E` (`usuario_id`);

--
-- Indices de la tabla `recurso_curso`
--
ALTER TABLE `recurso_curso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CCCE664F87CB4A1F` (`curso_id`);

--
-- Indices de la tabla `recurso_visto`
--
ALTER TABLE `recurso_visto`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_RECURSO_VISTO_USUARIO_RECURSO` (`usuario_id`,`recurso_id`),
  ADD KEY `IDX_RECURSO_VISTO_USUARIO` (`usuario_id`),
  ADD KEY `IDX_RECURSO_VISTO_RECURSO` (`recurso_id`);

--
-- Indices de la tabla `suscripcion_profesor`
--
ALTER TABLE `suscripcion_profesor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_SUSCRIPCION_PROFESOR` (`profesor_id`);

--
-- Indices de la tabla `tarea_curso`
--
ALTER TABLE `tarea_curso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_TAREA_CURSO_CURSO` (`curso_id`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_IDENTIFIER_EMAIL` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `curso`
--
ALTER TABLE `curso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `entrega_tarea`
--
ALTER TABLE `entrega_tarea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `inscripcion`
--
ALTER TABLE `inscripcion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `messenger_messages`
--
ALTER TABLE `messenger_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `recuperacion_contrasena`
--
ALTER TABLE `recuperacion_contrasena`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `recurso_curso`
--
ALTER TABLE `recurso_curso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `recurso_visto`
--
ALTER TABLE `recurso_visto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `suscripcion_profesor`
--
ALTER TABLE `suscripcion_profesor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `tarea_curso`
--
ALTER TABLE `tarea_curso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `FK_COMENTARIO_CURSO` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_COMENTARIO_USUARIO` FOREIGN KEY (`usuario_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `FK_CA3B40ECE52BD977` FOREIGN KEY (`profesor_id`) REFERENCES `user` (`id`);

--
-- Filtros para la tabla `entrega_tarea`
--
ALTER TABLE `entrega_tarea`
  ADD CONSTRAINT `FK_ENTREGA_TAREA_ESTUDIANTE` FOREIGN KEY (`estudiante_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_ENTREGA_TAREA_TAREA` FOREIGN KEY (`tarea_id`) REFERENCES `tarea_curso` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `inscripcion`
--
ALTER TABLE `inscripcion`
  ADD CONSTRAINT `FK_935E99F059590C39` FOREIGN KEY (`estudiante_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_935E99F087CB4A1F` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `recuperacion_contrasena`
--
ALTER TABLE `recuperacion_contrasena`
  ADD CONSTRAINT `FK_32D59BF1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `recurso_curso`
--
ALTER TABLE `recurso_curso`
  ADD CONSTRAINT `FK_CCCE664F87CB4A1F` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `recurso_visto`
--
ALTER TABLE `recurso_visto`
  ADD CONSTRAINT `FK_RECURSO_VISTO_RECURSO` FOREIGN KEY (`recurso_id`) REFERENCES `recurso_curso` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_RECURSO_VISTO_USUARIO` FOREIGN KEY (`usuario_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `suscripcion_profesor`
--
ALTER TABLE `suscripcion_profesor`
  ADD CONSTRAINT `FK_SUSCRIPCION_PROFESOR_USER` FOREIGN KEY (`profesor_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `tarea_curso`
--
ALTER TABLE `tarea_curso`
  ADD CONSTRAINT `FK_TAREA_CURSO_CURSO` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
