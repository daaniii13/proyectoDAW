<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Attribute\Route;

class ErrorController extends AbstractController
{
    #[Route('/pagina-no-encontrada', name: 'app_404_demo')]
    public function notFound()
    {
        return $this->render('paginas/errores/404.html.twig');
    }
}