<?php

namespace App\Controller;

use App\Repository\CursoRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Process\Process;
use Symfony\Component\Routing\Attribute\Route;

class ApiCursoController extends AbstractController
{
    #[Route('/api/cursos', name: 'api_cursos')]
    public function listar(
        Request $request,
        CursoRepository $repo
    ): JsonResponse {
        $busqueda = trim((string) $request->query->get('q', ''));
        $session = $request->getSession();

        if ($busqueda !== '') {
            $historialBusquedas = $session->get('busquedas', []);
            array_unshift($historialBusquedas, $busqueda);
            $session->set('busquedas', array_slice(array_unique($historialBusquedas), 0, 10));
        }

        // =========================
        // MODO 2: BÚSQUEDA NORMAL
        // =========================
        if ($busqueda !== '') {
            $resultados = $repo->buscarPorTexto($busqueda);

            if (!empty($resultados)) {
                $dataResultados = array_map(function ($curso) {
                    return [
                        'id' => $curso->getId(),
                        'titulo' => $curso->getTitulo(),
                        'descripcion' => $curso->getDescripcion(),
                        'nivel' => $curso->getNivel(),
                        'modalidad' => $curso->getModalidad(),
                        'profesor' => $curso->getProfesor()?->getNombre(),
                        'duracion' => $curso->getDuracion(),
                        'precio' => $curso->getPrecio(),
                        'detalleUrl' => $this->generateUrl('app_detalle_curso', ['id' => $curso->getId()]),
                    ];
                }, $resultados);

                return $this->json([
                    'modo' => 'resultados_busqueda',
                    'mensaje' => '',
                    'cursos' => $dataResultados,
                    'destacados' => [],
                ]);
            }
        }

        // Si no hay búsqueda o no hubo resultados, cargamos todos los activos
        $cursos = $repo->buscarCursosActivos();

        $data = array_map(function ($curso) {
            return [
                'id' => $curso->getId(),
                'titulo' => $curso->getTitulo(),
                'descripcion' => $curso->getDescripcion(),
                'nivel' => $curso->getNivel(),
                'modalidad' => $curso->getModalidad(),
                'profesor' => $curso->getProfesor()?->getNombre(),
                'duracion' => $curso->getDuracion(),
                'precio' => $curso->getPrecio(),
                'detalleUrl' => $this->generateUrl('app_detalle_curso', ['id' => $curso->getId()]),
            ];
        }, $cursos);

        $idsCursosClicados = $session->get('cursos_clicados_recientes', []);

        if (empty($idsCursosClicados)) {
            $idsCursosClicados = $session->get('clics', []);
        }

        $payload = [
            'cursos' => $data,
            'busqueda_actual' => $busqueda,
            'busquedas_recientes' => $session->get('busquedas', []),
            'ids_cursos_clicados' => $idsCursosClicados,
        ];

        $tmp = tempnam(sys_get_temp_dir(), 'rec_');
        file_put_contents($tmp, json_encode($payload, JSON_UNESCAPED_UNICODE));

        $script = $this->getParameter('kernel.project_dir') . '/python/recomendador.py';

        $process = new Process(['python', $script, $tmp]);
        $process->run();

        unlink($tmp);

        if (!$process->isSuccessful()) {
            return $this->json([
                'modo' => $busqueda === '' ? 'recomendados' : 'sin_resultados',
                'cursos' => [],
                'destacados' => array_slice($data, 0, 3),
                'mensaje' => $busqueda === '' ? '' : 'No hay resultados para esta búsqueda.',
            ]);
        }

        $salida = json_decode($process->getOutput(), true);

        if (!is_array($salida)) {
            return $this->json([
                'modo' => $busqueda === '' ? 'recomendados' : 'sin_resultados',
                'cursos' => [],
                'destacados' => array_slice($data, 0, 3),
                'mensaje' => $busqueda === '' ? '' : 'No hay resultados para esta búsqueda.',
            ]);
        }

        return $this->json($salida);
    }
}