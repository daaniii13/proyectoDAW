<?php

namespace App\Controller;

use App\Entity\Curso;
use App\Entity\SuscripcionProfesor;
use App\Repository\SuscripcionProfesorRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class AdminSuscripcionProfesorController extends AbstractController
{
    #[Route('/admin/profesores', name: 'app_admin_profesores', methods: ['GET'])]
    public function index(SuscripcionProfesorRepository $suscripcionProfesorRepository): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        return $this->render('paginas/admin/profesores.html.twig', [
            'solicitudesPendientes' => $suscripcionProfesorRepository->buscarPendientes(),
        ]);
    }

    #[Route('/admin/profesores/{id}/aprobar', name: 'app_admin_aprobar_profesor', methods: ['POST'])]
    public function aprobar(
        SuscripcionProfesor $suscripcionProfesor,
        Request $request,
        EntityManagerInterface $entityManager
    ): Response {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if (!$this->isCsrfTokenValid('aprobar_profesor_' . $suscripcionProfesor->getId(), (string) $request->request->get('_token'))) {
            throw $this->createAccessDeniedException('Token CSRF no válido.');
        }

        $tipoSolicitud = $suscripcionProfesor->getTipoSolicitud();
        $profesor = $suscripcionProfesor->getProfesor();

        if ($tipoSolicitud === 'cancelacion') {
            if ($profesor) {
                $cursosProfesor = $entityManager->getRepository(Curso::class)->findBy([
                    'profesor' => $profesor,
                ]);

                foreach ($cursosProfesor as $curso) {
                    $entityManager->remove($curso);
                }

                $rolesActuales = $profesor->getRoles();
                $rolesNuevos = array_values(array_filter(
                    $rolesActuales,
                    static fn (string $rol): bool => $rol !== 'ROLE_PROFESOR'
                ));

                if (!in_array('ROLE_ESTUDIANTE', $rolesNuevos, true)) {
                    $rolesNuevos[] = 'ROLE_ESTUDIANTE';
                }

                $profesor->setRoles($rolesNuevos);
            }

            $suscripcionProfesor->setEstado('cancelada');
            $suscripcionProfesor->setLimiteCursos(0);
            $suscripcionProfesor->setPlanSolicitado(null);
            $suscripcionProfesor->setTipoSolicitud(null);
            $suscripcionProfesor->setFechaAprobacion(new \DateTimeImmutable());

            $entityManager->flush();

            $this->addFlash('success', 'Cancelación aprobada. El profesor ha pasado a estudiante y sus cursos han sido eliminados.');

            return $this->redirectToRoute('app_admin_profesores');
        }

        $plan = (string) $request->request->get('plan');
        if (!in_array($plan, ['basico', 'pro', 'premium'], true)) {
            $plan = $suscripcionProfesor->getPlanSolicitado() ?: $suscripcionProfesor->getPlan();
        }

        $limite = match ($plan) {
            'basico' => 1,
            'pro' => 5,
            'premium' => 999,
            default => 1,
        };

        $suscripcionProfesor->setPlan($plan);
        $suscripcionProfesor->setEstado('activa');
        $suscripcionProfesor->setLimiteCursos($limite);
        $suscripcionProfesor->setPlanSolicitado(null);
        $suscripcionProfesor->setTipoSolicitud(null);
        $suscripcionProfesor->setFechaAprobacion(new \DateTimeImmutable());

        if ($profesor) {
            $rolesActuales = $profesor->getRoles();

            if (!in_array('ROLE_PROFESOR', $rolesActuales, true)) {
                $rolesActuales[] = 'ROLE_PROFESOR';
            }

            if (!in_array('ROLE_ESTUDIANTE', $rolesActuales, true)) {
                $rolesActuales[] = 'ROLE_ESTUDIANTE';
            }

            $profesor->setRoles($rolesActuales);
            $profesor->setActivo(true);
        }

        $entityManager->flush();

        $mensaje = $tipoSolicitud === 'cambio_plan'
            ? 'Cambio de plan aprobado correctamente.'
            : 'Profesor aprobado correctamente.';

        $this->addFlash('success', $mensaje);

        return $this->redirectToRoute('app_admin_profesores');
    }

    #[Route('/admin/profesores/{id}/rechazar', name: 'app_admin_rechazar_profesor', methods: ['POST'])]
    public function rechazar(
        SuscripcionProfesor $suscripcionProfesor,
        Request $request,
        EntityManagerInterface $entityManager
    ): Response {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if (!$this->isCsrfTokenValid('rechazar_profesor_' . $suscripcionProfesor->getId(), (string) $request->request->get('_token'))) {
            throw $this->createAccessDeniedException('Token CSRF no válido.');
        }

        $tipoSolicitud = $suscripcionProfesor->getTipoSolicitud();

        if ($tipoSolicitud === 'cancelacion') {
            $suscripcionProfesor->setEstado('activa');
            $suscripcionProfesor->setPlanSolicitado(null);
            $suscripcionProfesor->setTipoSolicitud(null);

            $entityManager->flush();

            $this->addFlash('success', 'Solicitud de cancelación rechazada.');

            return $this->redirectToRoute('app_admin_profesores');
        }

        if ($tipoSolicitud === 'cambio_plan') {
            $suscripcionProfesor->setPlanSolicitado(null);
            $suscripcionProfesor->setTipoSolicitud(null);

            $entityManager->flush();

            $this->addFlash('success', 'Solicitud de cambio de plan rechazada.');

            return $this->redirectToRoute('app_admin_profesores');
        }

        $suscripcionProfesor->setEstado('rechazada');
        $suscripcionProfesor->setPlanSolicitado(null);
        $suscripcionProfesor->setTipoSolicitud(null);
        $suscripcionProfesor->setFechaAprobacion(new \DateTimeImmutable());

        $entityManager->flush();

        $this->addFlash('success', 'Solicitud rechazada.');

        return $this->redirectToRoute('app_admin_profesores');
    }
}
