<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

class IdiomaController extends AbstractController
{
    #[Route('/idioma/{locale}', name: 'app_cambiar_idioma', methods: ['GET'])]
    public function cambiar(string $locale, Request $request): RedirectResponse
    {
        $idiomasPermitidos = ['es', 'en'];

        if (!in_array($locale, $idiomasPermitidos, true)) {
            $locale = 'es';
        }

        $request->getSession()->set('_locale', $locale);

        $referer = $request->headers->get('referer');

        if ($referer) {
            return $this->redirect($referer);
        }

        return $this->redirectToRoute('app_inicio');
    }
}