<?php

namespace App\Repository;

use App\Entity\EntregaComentario;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class EntregaComentarioRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, EntregaComentario::class);
    }

    public function buscarPorEntrega(int $entregaId): array
    {
        return $this->createQueryBuilder('c')
            ->join('c.entrega', 'e')
            ->where('e.id = :id')
            ->setParameter('id', $entregaId)
            ->orderBy('c.fecha', 'ASC')
            ->getQuery()
            ->getResult();
    }
}