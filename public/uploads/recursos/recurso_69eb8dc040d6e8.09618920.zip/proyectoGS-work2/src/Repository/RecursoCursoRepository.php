<?php

namespace App\Repository;

use App\Entity\RecursoCurso;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class RecursoCursoRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, RecursoCurso::class);
    }

    public function buscarPorCurso(int $cursoId): array
    {
        return $this->createQueryBuilder('r')
            ->join('r.curso', 'c')
            ->addSelect('c')
            ->where('c.id = :cursoId')
            ->setParameter('cursoId', $cursoId)
            ->orderBy('r.orden', 'ASC')
            ->addOrderBy('r.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function buscarRecursosAnteriores(int $cursoId, int $ordenActual): array
    {
        return $this->createQueryBuilder('r')
            ->join('r.curso', 'c')
            ->where('c.id = :cursoId')
            ->andWhere('r.orden < :ordenActual')
            ->setParameter('cursoId', $cursoId)
            ->setParameter('ordenActual', $ordenActual)
            ->orderBy('r.orden', 'ASC')
            ->addOrderBy('r.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function contarPorCurso(int $cursoId): int
    {
        return (int) $this->createQueryBuilder('r')
            ->select('COUNT(r.id)')
            ->join('r.curso', 'c')
            ->where('c.id = :cursoId')
            ->setParameter('cursoId', $cursoId)
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function contarRecursosDeProfesor(User $profesor): int
    {
        return (int) $this->createQueryBuilder('r')
            ->select('COUNT(r.id)')
            ->join('r.curso', 'c')
            ->where('c.profesor = :profesor')
            ->setParameter('profesor', $profesor)
            ->getQuery()
            ->getSingleScalarResult();
    }
}