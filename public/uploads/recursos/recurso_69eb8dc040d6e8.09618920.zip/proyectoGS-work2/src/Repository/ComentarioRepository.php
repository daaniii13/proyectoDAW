<?php

namespace App\Repository;

use App\Entity\Comentario;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class ComentarioRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Comentario::class);
    }

    public function buscarPorCurso(int $cursoId): array
    {
        return $this->createQueryBuilder('c')
            ->join('c.usuario', 'u')
            ->addSelect('u')
            ->where('c.curso = :curso')
            ->setParameter('curso', $cursoId)
            ->orderBy('c.destacado', 'DESC')
            ->addOrderBy('c.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarDestacados(int $cursoId): array
    {
        return $this->createQueryBuilder('c')
            ->join('c.usuario', 'u')
            ->addSelect('u')
            ->where('c.curso = :curso')
            ->andWhere('c.destacado = 1')
            ->setParameter('curso', $cursoId)
            ->orderBy('c.id', 'DESC')
            ->getQuery()
            ->getResult();
    }
}