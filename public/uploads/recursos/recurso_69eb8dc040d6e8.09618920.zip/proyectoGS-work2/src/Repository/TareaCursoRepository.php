<?php

namespace App\Repository;

use App\Entity\TareaCurso;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class TareaCursoRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, TareaCurso::class);
    }

    public function buscarPorCurso(int $cursoId): array
    {
        return $this->createQueryBuilder('t')
            ->join('t.curso', 'c')
            ->addSelect('c')
            ->where('c.id = :cursoId')
            ->setParameter('cursoId', $cursoId)
            ->orderBy('t.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function contarPorCurso(int $cursoId): int
    {
        return (int) $this->createQueryBuilder('t')
            ->select('COUNT(t.id)')
            ->join('t.curso', 'c')
            ->where('c.id = :cursoId')
            ->setParameter('cursoId', $cursoId)
            ->getQuery()
            ->getSingleScalarResult();
    }
}