<?php

namespace App\Repository;

use App\Entity\RecuperacionContrasena;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class RecuperacionContrasenaRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, RecuperacionContrasena::class);
    }

    public function buscarTokenValido(string $token): ?RecuperacionContrasena
    {
        return $this->createQueryBuilder('r')
            ->andWhere('r.token = :token')
            ->andWhere('r.usado = false')
            ->andWhere('r.fechaExpiracion > :ahora')
            ->setParameter('token', $token)
            ->setParameter('ahora', new \DateTimeImmutable())
            ->getQuery()
            ->getOneOrNullResult();
    }
}