<?php

namespace App\Repository;

use App\Entity\Curso;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class CursoRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Curso::class);
    }

    public function buscarCursosActivos(): array
    {
        return $this->createQueryBuilder('c')
            ->leftJoin('c.profesor', 'p')
            ->addSelect('p')
            ->where('c.estado = :estado')
            ->setParameter('estado', 'activo')
            ->orderBy('c.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarCursosActivosFiltrados(?string $busqueda, ?string $nivel, ?string $modalidad): array
    {
        $qb = $this->createQueryBuilder('c')
            ->leftJoin('c.profesor', 'p')
            ->addSelect('p')
            ->where('c.estado = :estado')
            ->setParameter('estado', 'activo');

        if ($busqueda !== null && $busqueda !== '') {
            $qb->andWhere('c.titulo LIKE :busqueda OR c.descripcion LIKE :busqueda OR p.nombre LIKE :busqueda')
                ->setParameter('busqueda', '%' . $busqueda . '%');
        }

        if ($nivel !== null && $nivel !== '') {
            $qb->andWhere('c.nivel = :nivel')
                ->setParameter('nivel', $nivel);
        }

        if ($modalidad !== null && $modalidad !== '') {
            $qb->andWhere('c.modalidad = :modalidad')
                ->setParameter('modalidad', $modalidad);
        }

        return $qb
            ->orderBy('c.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarPorTexto(string $texto): array
    {
        return $this->createQueryBuilder('c')
            ->leftJoin('c.profesor', 'p')
            ->addSelect('p')
            ->where('(c.titulo LIKE :texto OR c.descripcion LIKE :texto OR p.nombre LIKE :texto)')
            ->andWhere('c.estado = :estado')
            ->setParameter('texto', '%' . $texto . '%')
            ->setParameter('estado', 'activo')
            ->orderBy('c.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarCursosDeProfesor(User $profesor): array
    {
        return $this->createQueryBuilder('c')
            ->where('c.profesor = :profesor')
            ->setParameter('profesor', $profesor)
            ->orderBy('c.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function contarCursosDeProfesor(User $profesor): int
    {
        return (int) $this->createQueryBuilder('c')
            ->select('COUNT(c.id)')
            ->where('c.profesor = :profesor')
            ->setParameter('profesor', $profesor)
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function contarCursosActivosDeProfesor(User $profesor): int
    {
        return (int) $this->createQueryBuilder('c')
            ->select('COUNT(c.id)')
            ->where('c.profesor = :profesor')
            ->andWhere('c.estado = :estado')
            ->setParameter('profesor', $profesor)
            ->setParameter('estado', 'activo')
            ->getQuery()
            ->getSingleScalarResult();
    }
}