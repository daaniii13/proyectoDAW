<?php

namespace App\Repository;

use App\Entity\Inscripcion;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class InscripcionRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Inscripcion::class);
    }

    public function buscarInscripcionesDeEstudiante(User $estudiante): array
    {
        return $this->createQueryBuilder('i')
            ->join('i.curso', 'c')
            ->leftJoin('c.profesor', 'p')
            ->addSelect('c', 'p')
            ->where('i.estudiante = :estudiante')
            ->setParameter('estudiante', $estudiante)
            ->orderBy('i.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarInscripcionPorCursoYEstudiante(int $cursoId, User $estudiante): ?Inscripcion
    {
        return $this->createQueryBuilder('i')
            ->join('i.curso', 'c')
            ->where('c.id = :cursoId')
            ->andWhere('i.estudiante = :estudiante')
            ->setParameter('cursoId', $cursoId)
            ->setParameter('estudiante', $estudiante)
            ->getQuery()
            ->getOneOrNullResult();
    }

    public function buscarUnaInscripcion(User $estudiante, int $cursoId): ?Inscripcion
    {
        return $this->createQueryBuilder('i')
            ->join('i.curso', 'c')
            ->where('i.estudiante = :estudiante')
            ->andWhere('c.id = :cursoId')
            ->setParameter('estudiante', $estudiante)
            ->setParameter('cursoId', $cursoId)
            ->getQuery()
            ->getOneOrNullResult();
    }

    public function contarInscripcionesDeEstudiante(User $estudiante): int
    {
        return (int) $this->createQueryBuilder('i')
            ->select('COUNT(i.id)')
            ->where('i.estudiante = :estudiante')
            ->setParameter('estudiante', $estudiante)
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function contarInscripcionesEnCursosDeProfesor(User $profesor): int
    {
        return (int) $this->createQueryBuilder('i')
            ->select('COUNT(i.id)')
            ->join('i.curso', 'c')
            ->where('c.profesor = :profesor')
            ->setParameter('profesor', $profesor)
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function calcularProgresoMedioDeEstudiante(User $estudiante): int
    {
        $resultado = $this->createQueryBuilder('i')
            ->select('AVG(i.progreso) as progreso_medio')
            ->where('i.estudiante = :estudiante')
            ->setParameter('estudiante', $estudiante)
            ->getQuery()
            ->getOneOrNullResult();

        if (!$resultado || $resultado['progreso_medio'] === null) {
            return 0;
        }

        return (int) round((float) $resultado['progreso_medio']);
    }

    public function buscarSolicitudesPendientesDeProfesor(User $profesor): array
    {
        return $this->createQueryBuilder('i')
            ->join('i.curso', 'c')
            ->join('i.estudiante', 'e')
            ->addSelect('c', 'e')
            ->where('c.profesor = :profesor')
            ->andWhere('i.estado = :estado')
            ->setParameter('profesor', $profesor)
            ->setParameter('estado', 'pendiente_validacion')
            ->orderBy('i.id', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarInscripcionDeProfesorPorId(User $profesor, int $inscripcionId): ?Inscripcion
    {
        return $this->createQueryBuilder('i')
            ->join('i.curso', 'c')
            ->where('i.id = :inscripcionId')
            ->andWhere('c.profesor = :profesor')
            ->setParameter('inscripcionId', $inscripcionId)
            ->setParameter('profesor', $profesor)
            ->getQuery()
            ->getOneOrNullResult();
    }

    public function buscarAlumnosPorCurso(int $cursoId): array
    {
        return $this->createQueryBuilder('i')
            ->join('i.estudiante', 'u')
            ->addSelect('u')
            ->join('i.curso', 'c')
            ->addSelect('c')
            ->where('c.id = :cursoId')
            ->andWhere('i.estado IN (:estados)')
            ->setParameter('cursoId', $cursoId)
            ->setParameter('estados', ['activa', 'completada'])
            ->orderBy('i.id', 'DESC')
            ->getQuery()
            ->getResult();
    }
    public function buscarPorCurso(int $cursoId): array
    {
    return $this->createQueryBuilder('i')
        ->join('i.estudiante', 'u')
        ->where('i.curso = :cursoId')
        ->andWhere('u IS NOT NULL')
        ->setParameter('cursoId', $cursoId)
        ->getQuery()
        ->getResult();
    }
}