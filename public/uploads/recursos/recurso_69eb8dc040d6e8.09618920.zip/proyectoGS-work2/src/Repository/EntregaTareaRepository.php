<?php

namespace App\Repository;

use App\Entity\EntregaTarea;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class EntregaTareaRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, EntregaTarea::class);
    }

    public function buscarUnaEntrega(int $tareaId, User $estudiante): ?EntregaTarea
    {
        return $this->createQueryBuilder('e')
            ->join('e.tarea', 't')
            ->where('t.id = :tareaId')
            ->andWhere('e.estudiante = :estudiante')
            ->setParameter('tareaId', $tareaId)
            ->setParameter('estudiante', $estudiante)
            ->getQuery()
            ->getOneOrNullResult();
    }

    public function buscarEntregasDeEstudiantePorCurso(User $estudiante, int $cursoId): array
    {
        return $this->createQueryBuilder('e')
            ->join('e.tarea', 't')
            ->addSelect('t')
            ->join('t.curso', 'c')
            ->where('e.estudiante = :estudiante')
            ->andWhere('c.id = :cursoId')
            ->setParameter('estudiante', $estudiante)
            ->setParameter('cursoId', $cursoId)
            ->orderBy('t.id', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function contarEntregasAprobadasDeEstudiantePorCurso(User $estudiante, int $cursoId): int
    {
        return (int) $this->createQueryBuilder('e')
            ->select('COUNT(e.id)')
            ->join('e.tarea', 't')
            ->join('t.curso', 'c')
            ->where('e.estudiante = :estudiante')
            ->andWhere('c.id = :cursoId')
            ->andWhere('e.estadoRevision = :estado')
            ->setParameter('estudiante', $estudiante)
            ->setParameter('cursoId', $cursoId)
            ->setParameter('estado', 'aprobada')
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function buscarEntregasPorCurso(int $cursoId): array
    {
        return $this->createQueryBuilder('e')
            ->join('e.tarea', 't')
            ->addSelect('t')
            ->join('t.curso', 'c')
            ->addSelect('c')
            ->join('e.estudiante', 'u')
            ->addSelect('u')
            ->where('c.id = :cursoId')
            ->setParameter('cursoId', $cursoId)
            ->orderBy('e.estadoRevision', 'ASC')
            ->addOrderBy('e.fechaEntrega', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function buscarEntregasPendientesPorCurso(int $cursoId): array
    {
        return $this->createQueryBuilder('e')
            ->join('e.tarea', 't')
            ->addSelect('t')
            ->join('t.curso', 'c')
            ->addSelect('c')
            ->join('e.estudiante', 'u')
            ->addSelect('u')
            ->where('c.id = :cursoId')
            ->andWhere('e.estadoRevision = :estado')
            ->setParameter('cursoId', $cursoId)
            ->setParameter('estado', 'pendiente')
            ->orderBy('e.fechaEntrega', 'DESC')
            ->getQuery()
            ->getResult();
    }
}