<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Comentario
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Curso $curso = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?User $usuario = null;

    #[ORM\Column(type: 'text')]
    private string $contenido;

    #[ORM\Column]
    private bool $destacado = false;

    #[ORM\Column]
    private \DateTime $fechaCreacion;

    public function __construct()
    {
        $this->fechaCreacion = new \DateTime();
    }

    public function getId(): ?int { return $this->id; }

    public function getCurso(): ?Curso { return $this->curso; }
    public function setCurso(?Curso $curso): static { $this->curso = $curso; return $this; }

    public function getUsuario(): ?User { return $this->usuario; }
    public function setUsuario(?User $usuario): static { $this->usuario = $usuario; return $this; }

    public function getContenido(): string { return $this->contenido; }
    public function setContenido(string $contenido): static { $this->contenido = $contenido; return $this; }

    public function isDestacado(): bool { return $this->destacado; }
    public function setDestacado(bool $destacado): static { $this->destacado = $destacado; return $this; }

    public function getFechaCreacion(): \DateTime { return $this->fechaCreacion; }
}