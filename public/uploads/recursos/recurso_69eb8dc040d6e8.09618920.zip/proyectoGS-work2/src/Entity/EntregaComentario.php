<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class EntregaComentario
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?EntregaTarea $entrega = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private ?User $autor = null;

    #[ORM\Column(type: 'text')]
    private string $mensaje;

    #[ORM\Column(type: 'datetime')]
    private \DateTimeInterface $fecha;

    public function __construct()
    {
        $this->fecha = new \DateTime();
    }

    public function getId(): ?int { return $this->id; }
    public function getEntrega(): ?EntregaTarea { return $this->entrega; }
    public function setEntrega(?EntregaTarea $e): static { $this->entrega = $e; return $this; }
    public function getAutor(): ?User { return $this->autor; }
    public function setAutor(?User $a): static { $this->autor = $a; return $this; }
    public function getMensaje(): string { return $this->mensaje; }
    public function setMensaje(string $m): static { $this->mensaje = $m; return $this; }
    public function getFecha(): \DateTimeInterface { return $this->fecha; }
}