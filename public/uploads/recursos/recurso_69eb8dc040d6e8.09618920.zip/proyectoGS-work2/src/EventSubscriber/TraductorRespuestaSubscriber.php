<?php

namespace App\EventSubscriber;

use App\Service\TraductorDinamico;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class TraductorRespuestaSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly TraductorDinamico $traductorDinamico
    ) {
    }

    public function onKernelResponse(ResponseEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $request = $event->getRequest();
        $response = $event->getResponse();

        if ($request->isXmlHttpRequest()) {
            return;
        }

        $path = $request->getPathInfo();
        if (
            str_starts_with($path, '/_wdt') ||
            str_starts_with($path, '/_profiler') ||
            str_starts_with($path, '/build') ||
            str_starts_with($path, '/uploads')
        ) {
            return;
        }

        $contentType = (string) $response->headers->get('Content-Type', '');
        if (!str_contains($contentType, 'text/html')) {
            return;
        }

        $locale = (string) $request->getLocale();
        if ($locale === '' || $locale === 'es') {
            return;
        }

        $html = $response->getContent();
        if (!is_string($html) || trim($html) === '') {
            return;
        }

        $response->setContent(
            $this->traductorDinamico->traducirContenidoRenderizado($html, $locale, 'es')
        );
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::RESPONSE => ['onKernelResponse', -10],
        ];
    }
}