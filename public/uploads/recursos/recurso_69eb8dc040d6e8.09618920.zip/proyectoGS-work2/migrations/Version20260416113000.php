<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260416113000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Elimina tablas no usadas: actividad_usuario y notificacion';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('DROP TABLE IF EXISTS actividad_usuario');
        $this->addSql('DROP TABLE IF EXISTS notificacion');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('CREATE TABLE actividad_usuario (id INT AUTO_INCREMENT NOT NULL, usuario_id INT DEFAULT NULL, tipo VARCHAR(50) NOT NULL, curso_id INT DEFAULT NULL, texto VARCHAR(255) DEFAULT NULL, fecha DATETIME NOT NULL, INDEX IDX_7D694D43DB38439E (usuario_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE actividad_usuario ADD CONSTRAINT FK_7D694D43DB38439E FOREIGN KEY (usuario_id) REFERENCES user (id)');

        $this->addSql('CREATE TABLE notificacion (id INT AUTO_INCREMENT NOT NULL, usuario_id INT DEFAULT NULL, mensaje LONGTEXT NOT NULL, leida TINYINT(1) NOT NULL, fecha DATETIME NOT NULL, INDEX IDX_BF5476CADB38439E (usuario_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE notificacion ADD CONSTRAINT FK_BF5476CADB38439E FOREIGN KEY (usuario_id) REFERENCES user (id)');
    }
}
